#!bin/bash
YELLOW='\033[1;33m'
while : 
do
echo "${YELLOW} Bot-sinais _ Auto reconexão ativada para prevenção de quedas.."
    python bot.py
    sleep 1

done